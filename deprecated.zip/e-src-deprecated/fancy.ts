import { reporterDemo } from "./utils/index.js";

reporterDemo({
  fancy: true,
});
